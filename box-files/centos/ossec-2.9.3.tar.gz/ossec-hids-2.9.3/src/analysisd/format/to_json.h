/* Copyright (C) 2015 Trend Micro Inc.
 * All rights reserved.
 *
 * This program is a free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public
 * License (version 2) as published by the FSF - Free Software
 * Foundation.
 */

#ifndef __TO_JSON_H__
#define __TO_JSON_H__

#include "eventinfo.h"
char *Eventinfo_to_jsonstr(const Eventinfo *lf);

#endif /* __TO_JSON_H__ */
